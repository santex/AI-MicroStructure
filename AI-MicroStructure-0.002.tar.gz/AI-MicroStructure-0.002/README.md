AI-MicroStructure
=================

A concept is a mental representation for a word or any form of inputs!

Concepts allows us to draw appropriate inferences about the type of entities we encounter in our everyday lives!

The use of concepts is necessary to cognitive processes such as categorization, memory, decision making, learning and inference.

AI-MicroStructure is a package to build concepts for words.

Anybody whisching to do categorization, memory, decision making, learning and inference.

requires as much concepts for a specific (word,idea,sensor input) as possible to base any further knowledge or decission on

to be able to fly you require only to types


micro new fly
  
               .--'"""""--.>_
            .-'  o\\b.\o._o.`-.
         .-'.- )  \d888888888888b.
        /.'   b  Y8888888888888888b.
      .-'. 8888888888888888888888888b
     / o888 Y Y8888888888888888888888b
     / d888P/ /| Y"Y8888888888888888888b
   J d8888/| Y .o._. "Y8888888888888Y" \
   |d Y888b|obd88888bo. """Y88888Y' .od8
   Fdd 8888888888888888888bo._'|| d88888|
   Fd d 88\ Y8888Y "Y888888888b, d888888P
   d-b 8888b Y88P'     """""Y888b8888P"|
  J  8\88888888P    `m.        """""   |
  || `8888888P'       "Ymm._          _J
  |\\  Y8888P  '     .mmm.YM)     .mMF"'
  | \\  Y888J     ' < (@)>.- `   /MFm. |
  J   \  `YY           ""'   ::  MM @)>F
   L  /)  88                  :  |  ""\|
   | ( (   Yb .            '  .  |     L
   \   bo  8b    .            .  J     |        The word fly
    \      "' .      .    .    .  L   F         has 14 concept's
     o._.:.    .        .  \mm,__J/  /          we need to find out the which one
     Y8::'|.            /     `Y8P  J           to use for our new,
     `|'  J:   . .     '   .  .   | F           micro-structure,
      |    L          ' .    _:    |            
      |    `:        . .:oood8bdb. |            (1): two-winged insects characterized by active flight fly, wing
      F     `:.          "-._   `" F            (2): flap consisting of a piece of canvas that can be drawn back to provide entrance to a tent fly
     /       `::.           """'  /             (3): an opening in a garment that is closed by a zipper or by buttons concealed under a fold of cloth fly, aviate, pilot
    /         `::.          ""   /              (4): baseball a hit that flies up in the air
_.-d(          `:::.            F               (5): fishermans lure consisting of a fishhook decorated to look like an insect fly
-888b.          `::::.     .  J                 (6): be dispersed or disseminated rumors and accusations are flying
Y888888b.          `::::::::::'                 (7): change quickly from one emotional state to another fly into a rage
Y88888888bo.        `::::::d                    (8): pass away rapidly time flies like an arrow
`"Y8888888888boo.._   `"dd88b.                  (9): travel in an airplane she is flying to cincinnati tonight





"""""""""""""""""""""""""""""""""""""""""""""""


(10): display in the air or cause to float fly a kite
(11): run away quickly he threw down his gun and fled
(12): travel over an area of land or sea
(13): hit a fly
(14): decrease rapidly and disappear the money vanished in las vegas
  Type: the number you choose 1..14
  1
fly
housefly
house_fly
musca_domestica
tsetse_fly
tsetse
tzetze_fly
tzetze
glossina
blowfly
blow_fly
flesh_fly
sarcophaga_carnaria
tachina_fly
gadfly
bee_fly
horn_fly
haematobia_irritans
fly
dipterous_insect
two-winged_insects
dipteran
dipteron
insect
arthropod
invertebrate
animal
animate_being
beast
brute
creature
fauna
organism
being
living_thing
animate_thing
whole
unit
object
physical_object
physical_entity
entity
fly
wing
travel
go
move
locomote
fly
dipterous_insect
two-winged_insects
dipteran
dipteron





  ☞ [sample](http://quantup.com)

  ☞ [PDF info](https://github.com/santex/active-memory/raw/master/start-here.pdf)



#### Copyright

  Copyright (C) 2009-2012 Hagen "santex" Geissler
